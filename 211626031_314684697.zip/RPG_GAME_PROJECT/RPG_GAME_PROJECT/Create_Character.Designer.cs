﻿
namespace RPG_GAME_PROJECT
{
    partial class Create_Character
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Create_Character));
            this.panel1 = new System.Windows.Forms.Panel();
            this.save_button = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Knight = new System.Windows.Forms.RadioButton();
            this.Mage = new System.Windows.Forms.RadioButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.offense_defense = new System.Windows.Forms.GroupBox();
            this.Offense = new System.Windows.Forms.RadioButton();
            this.Defense = new System.Windows.Forms.RadioButton();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Demon = new System.Windows.Forms.RadioButton();
            this.Dark_Mage = new System.Windows.Forms.RadioButton();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.hero_attack = new System.Windows.Forms.PictureBox();
            this.Special = new System.Windows.Forms.Button();
            this.player_mana = new System.Windows.Forms.Label();
            this.npc_h = new System.Windows.Forms.Label();
            this.npc_mana = new System.Windows.Forms.Label();
            this.player_h = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.player_pic = new System.Windows.Forms.PictureBox();
            this.enemy_pic = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.offense_defense.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hero_attack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.save_button);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.offense_defense);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(57, 10);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(619, 444);
            this.panel1.TabIndex = 3;
            // 
            // save_button
            // 
            this.save_button.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.save_button.Location = new System.Drawing.Point(194, 392);
            this.save_button.Name = "save_button";
            this.save_button.Size = new System.Drawing.Size(143, 45);
            this.save_button.TabIndex = 25;
            this.save_button.Text = "Save and continu";
            this.save_button.UseVisualStyleBackColor = false;
            this.save_button.Click += new System.EventHandler(this.save_button_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Knight);
            this.groupBox1.Controls.Add(this.Mage);
            this.groupBox1.Location = new System.Drawing.Point(73, 337);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(510, 48);
            this.groupBox1.TabIndex = 24;
            this.groupBox1.TabStop = false;
            // 
            // Knight
            // 
            this.Knight.AutoSize = true;
            this.Knight.Location = new System.Drawing.Point(293, 19);
            this.Knight.Name = "Knight";
            this.Knight.Size = new System.Drawing.Size(55, 17);
            this.Knight.TabIndex = 1;
            this.Knight.Text = "Knight";
            this.Knight.UseVisualStyleBackColor = true;
            // 
            // Mage
            // 
            this.Mage.AutoSize = true;
            this.Mage.Location = new System.Drawing.Point(70, 19);
            this.Mage.Name = "Mage";
            this.Mage.Size = new System.Drawing.Size(52, 17);
            this.Mage.TabIndex = 0;
            this.Mage.Text = "Mage";
            this.Mage.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(137, 198);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(114, 114);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(366, 198);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(114, 114);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 21;
            this.pictureBox3.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(28, 163);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(159, 20);
            this.label2.TabIndex = 20;
            this.label2.Text = "Choose Character:";
            // 
            // offense_defense
            // 
            this.offense_defense.Controls.Add(this.Offense);
            this.offense_defense.Controls.Add(this.Defense);
            this.offense_defense.Location = new System.Drawing.Point(60, 74);
            this.offense_defense.Name = "offense_defense";
            this.offense_defense.Size = new System.Drawing.Size(172, 49);
            this.offense_defense.TabIndex = 19;
            this.offense_defense.TabStop = false;
            this.offense_defense.Text = "offense_defense";
            // 
            // Offense
            // 
            this.Offense.AutoSize = true;
            this.Offense.Location = new System.Drawing.Point(99, 20);
            this.Offense.Name = "Offense";
            this.Offense.Size = new System.Drawing.Size(62, 17);
            this.Offense.TabIndex = 1;
            this.Offense.TabStop = true;
            this.Offense.Text = "Offense";
            this.Offense.UseVisualStyleBackColor = true;
            // 
            // Defense
            // 
            this.Defense.AutoSize = true;
            this.Defense.Location = new System.Drawing.Point(7, 20);
            this.Defense.Name = "Defense";
            this.Defense.Size = new System.Drawing.Size(65, 17);
            this.Defense.TabIndex = 0;
            this.Defense.TabStop = true;
            this.Defense.Text = "Defense";
            this.Defense.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.textBox1.Location = new System.Drawing.Point(88, 22);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(118, 20);
            this.textBox1.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(22, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 20);
            this.label1.TabIndex = 17;
            this.label1.Text = "Name:";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.pictureBox4);
            this.panel2.Controls.Add(this.pictureBox5);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.panel2.Location = new System.Drawing.Point(41, 20);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(553, 375);
            this.panel2.TabIndex = 25;
            this.panel2.UseWaitCursor = true;
            this.panel2.Visible = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Demon);
            this.groupBox2.Controls.Add(this.Dark_Mage);
            this.groupBox2.Location = new System.Drawing.Point(131, 255);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(361, 48);
            this.groupBox2.TabIndex = 24;
            this.groupBox2.TabStop = false;
            this.groupBox2.UseWaitCursor = true;
            // 
            // Demon
            // 
            this.Demon.AutoSize = true;
            this.Demon.Location = new System.Drawing.Point(289, 19);
            this.Demon.Name = "Demon";
            this.Demon.Size = new System.Drawing.Size(59, 17);
            this.Demon.TabIndex = 20;
            this.Demon.Text = "Demon";
            this.Demon.UseVisualStyleBackColor = true;
            this.Demon.UseWaitCursor = true;
            // 
            // Dark_Mage
            // 
            this.Dark_Mage.AutoSize = true;
            this.Dark_Mage.Location = new System.Drawing.Point(13, 19);
            this.Dark_Mage.Name = "Dark_Mage";
            this.Dark_Mage.Size = new System.Drawing.Size(81, 17);
            this.Dark_Mage.TabIndex = 19;
            this.Dark_Mage.Text = "Dark_Mage";
            this.Dark_Mage.UseVisualStyleBackColor = true;
            this.Dark_Mage.UseWaitCursor = true;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(144, 96);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(114, 114);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 22;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.UseWaitCursor = true;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(391, 94);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(114, 114);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 21;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.UseWaitCursor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(178, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(292, 36);
            this.label3.TabIndex = 18;
            this.label3.Text = "choose enemy class:";
            this.label3.UseWaitCursor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(238, 323);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(118, 49);
            this.button2.TabIndex = 23;
            this.button2.Text = "PLAY";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.UseWaitCursor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel3
            // 
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.Controls.Add(this.pictureBox2);
            this.panel3.Controls.Add(this.hero_attack);
            this.panel3.Controls.Add(this.Special);
            this.panel3.Controls.Add(this.player_mana);
            this.panel3.Controls.Add(this.npc_h);
            this.panel3.Controls.Add(this.npc_mana);
            this.panel3.Controls.Add(this.player_h);
            this.panel3.Controls.Add(this.button5);
            this.panel3.Controls.Add(this.button4);
            this.panel3.Controls.Add(this.button3);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.player_pic);
            this.panel3.Controls.Add(this.enemy_pic);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Location = new System.Drawing.Point(21, 32);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(619, 461);
            this.panel3.TabIndex = 26;
            this.panel3.Visible = false;
            // 
            // hero_attack
            // 
            this.hero_attack.BackColor = System.Drawing.Color.Transparent;
            this.hero_attack.Cursor = System.Windows.Forms.Cursors.Default;
            this.hero_attack.Location = new System.Drawing.Point(151, 227);
            this.hero_attack.Name = "hero_attack";
            this.hero_attack.Size = new System.Drawing.Size(91, 82);
            this.hero_attack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.hero_attack.TabIndex = 26;
            this.hero_attack.TabStop = false;
            this.hero_attack.Visible = false;
            // 
            // Special
            // 
            this.Special.Location = new System.Drawing.Point(230, 404);
            this.Special.Name = "Special";
            this.Special.Size = new System.Drawing.Size(92, 39);
            this.Special.TabIndex = 25;
            this.Special.Text = "Special";
            this.Special.UseVisualStyleBackColor = true;
            this.Special.Click += new System.EventHandler(this.button4_Click);
            // 
            // player_mana
            // 
            this.player_mana.AutoSize = true;
            this.player_mana.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.player_mana.Font = new System.Drawing.Font("Stencil", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player_mana.Location = new System.Drawing.Point(26, 373);
            this.player_mana.Name = "player_mana";
            this.player_mana.Size = new System.Drawing.Size(79, 22);
            this.player_mana.TabIndex = 22;
            this.player_mana.Text = "Mana: ";
            // 
            // npc_h
            // 
            this.npc_h.AutoSize = true;
            this.npc_h.BackColor = System.Drawing.Color.Red;
            this.npc_h.Font = new System.Drawing.Font("Stencil", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npc_h.Location = new System.Drawing.Point(472, 353);
            this.npc_h.Name = "npc_h";
            this.npc_h.Size = new System.Drawing.Size(101, 22);
            this.npc_h.TabIndex = 21;
            this.npc_h.Text = "Health: ";
            // 
            // npc_mana
            // 
            this.npc_mana.AutoSize = true;
            this.npc_mana.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.npc_mana.Font = new System.Drawing.Font("Stencil", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npc_mana.Location = new System.Drawing.Point(477, 399);
            this.npc_mana.Name = "npc_mana";
            this.npc_mana.Size = new System.Drawing.Size(79, 22);
            this.npc_mana.TabIndex = 20;
            this.npc_mana.Text = "Mana: ";
            // 
            // player_h
            // 
            this.player_h.AutoSize = true;
            this.player_h.BackColor = System.Drawing.Color.Red;
            this.player_h.Font = new System.Drawing.Font("Stencil", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player_h.Location = new System.Drawing.Point(30, 334);
            this.player_h.Name = "player_h";
            this.player_h.Size = new System.Drawing.Size(101, 22);
            this.player_h.TabIndex = 18;
            this.player_h.Text = "Health: ";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(30, 26);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(92, 39);
            this.button5.TabIndex = 17;
            this.button5.Text = "Start";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(125, 404);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(92, 39);
            this.button4.TabIndex = 16;
            this.button4.Text = "Attack";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(18, 404);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(92, 39);
            this.button3.TabIndex = 15;
            this.button3.Text = "Mana_Attack";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button4_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(34, 137);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 24);
            this.label6.TabIndex = 14;
            this.label6.Text = "PLAYER";
            // 
            // player_pic
            // 
            this.player_pic.BackColor = System.Drawing.Color.Transparent;
            this.player_pic.Location = new System.Drawing.Point(18, 213);
            this.player_pic.Name = "player_pic";
            this.player_pic.Size = new System.Drawing.Size(120, 106);
            this.player_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.player_pic.TabIndex = 13;
            this.player_pic.TabStop = false;
            // 
            // enemy_pic
            // 
            this.enemy_pic.BackColor = System.Drawing.Color.Transparent;
            this.enemy_pic.Location = new System.Drawing.Point(479, 185);
            this.enemy_pic.Name = "enemy_pic";
            this.enemy_pic.Size = new System.Drawing.Size(122, 143);
            this.enemy_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemy_pic.TabIndex = 12;
            this.enemy_pic.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(481, 26);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 39);
            this.button1.TabIndex = 11;
            this.button1.Text = "EXIT";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(490, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 24);
            this.label5.TabIndex = 10;
            this.label5.Text = "ENEMY";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Palatino Linotype", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(203, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(134, 47);
            this.label4.TabIndex = 9;
            this.label4.Text = "FIGHT";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Location = new System.Drawing.Point(357, 227);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 82);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 27;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Visible = false;
            // 
            // Create_Character
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(679, 493);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.HelpButton = true;
            this.Name = "Create_Character";
            this.Text = "Create_Character";
            this.Load += new System.EventHandler(this.Create_Character_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.offense_defense.ResumeLayout(false);
            this.offense_defense.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hero_attack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton Knight;
        private System.Windows.Forms.RadioButton Mage;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox offense_defense;
        private System.Windows.Forms.RadioButton Offense;
        private System.Windows.Forms.RadioButton Defense;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton Demon;
        private System.Windows.Forms.RadioButton Dark_Mage;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button save_button;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox player_pic;
        private System.Windows.Forms.PictureBox enemy_pic;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label player_mana;
        private System.Windows.Forms.Label npc_h;
        private System.Windows.Forms.Label npc_mana;
        private System.Windows.Forms.Label player_h;
        private System.Windows.Forms.Button Special;
        private System.Windows.Forms.PictureBox hero_attack;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}