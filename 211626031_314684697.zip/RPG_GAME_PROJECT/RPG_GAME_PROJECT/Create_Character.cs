﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using RPG_GAME_PROJECT.character_Class;
namespace RPG_GAME_PROJECT
{
    public partial class Create_Character : Form
    {
        public Create_Character()
        {
            InitializeComponent();
        }
        List<entity> checking = new List<entity>();
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        private void Create_Character_Load(object sender, EventArgs e)
        {

        }
        private void button2_Click(object sender, EventArgs e)
        {
            string enemy_name;
            int str, mp, hp, special;
            if (this.Demon.Checked == false && this.Dark_Mage.Checked == false)
            {
                MessageBox.Show("choose enemy.");
                return;
            }
            if (this.Demon.Checked)
            {
                enemy_name = Demon.Text;
                str = 100;
                mp = 110;
                hp = 110;
                special = 5;
                NPC new_demon = new NPC(enemy_name, str, hp, mp);
                checking.Add(new_demon);
                store_NPC(new_demon);

            }
            if (this.Dark_Mage.Checked)
            {
                enemy_name = Dark_Mage.Text;
                str = 90;
                mp = 120;
                hp = 100;
                NPC new_darkmage = new NPC(enemy_name, str, hp, mp);
                checking.Add(new_darkmage);
                store_NPC(new_darkmage);
            }
            panel2.Visible = false;
            panel3.Visible = true;
        }
        private void save_button_Click(object sender, EventArgs e)
        {
            string name, character_class;
            Offense_Defense of_def = new Offense_Defense();
            of_def = Offense_Defense.Unknown;

            if (String.IsNullOrEmpty(textBox1.Text) || textBox1.Text[0] == ' ')
            {
                MessageBox.Show("name you character.");
                return;
            }
            name = this.textBox1.Text;
            if (this.Offense.Checked)
            {
                of_def = Offense_Defense.Offense;
            }
            else if (this.Defense.Checked)
            {
                of_def = Offense_Defense.Defense;
            }
            else
            {
                MessageBox.Show("choose boost.");
                return;
            }
            if (this.Mage.Checked == true)
            {
                character_class = Mage.Text;
                Mage mage_p = new Mage(name, of_def, 20, 100, 110, character_class);
                checking.Add(mage_p);
                store_Mage(mage_p);
            }
            else if (this.Knight.Checked == true)
            {
                character_class = Knight.Text;
                Knight knight_p = new Knight(name, of_def, 25, 110, 90, character_class);
                checking.Add(knight_p);
                store_Knight(knight_p);
            }
            else
            {
                MessageBox.Show("choose character.");
                return;
            }
            Create_Character button = new Create_Character();
            panel1.Visible = false;
            panel2.Visible = true;
        }
        private static String SettingFolder
        {
            get
            {
                string folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "RPG_GAME_PROJECT");
                folder = Path.Combine(folder, "characterSettings");
                if (!Directory.Exists(folder))
                    Directory.CreateDirectory(folder);
                return folder;
            }
        }
        private static String player_settingfile
        {
            get
            {
                return Path.Combine(SettingFolder, "player.xml");
            }
        }
        private void store_Knight(Knight knight_lf)
        {
            using (Stream stream = File.Create(player_settingfile))
            {
                XmlSerializer ser = new XmlSerializer(knight_lf.GetType());
                ser.Serialize(stream, o: knight_lf);
            }
        }
        private void store_Mage(Mage mage_lf)
        {
            using (Stream stream = File.Create(player_settingfile))
            {
                XmlSerializer ser = new XmlSerializer(mage_lf.GetType());
                ser.Serialize(stream, o: mage_lf);
            }
        }
        private void store_NPC(NPC demon_darkmage)
        {
            using (Stream stream = File.Create(npc_settings))
            {
                XmlSerializer ser = new XmlSerializer(demon_darkmage.GetType());
                ser.Serialize(stream, o: demon_darkmage);
            }
        }
        private static String npc_settings
        {
            get
            {
                return Path.Combine(SettingFolder, "npc.xml");
            }
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            Create_Character EXIT = new Create_Character();
            this.Close();
        }
        private static NPC LoadNPC()
        {
            using (Stream stream = File.OpenRead(npc_settings))
            {
                XmlSerializer ser = new XmlSerializer(typeof(NPC));
                return (NPC)ser.Deserialize(stream);
            }
        }
        private static Knight LoadKnight()
        {
            using (Stream stream = File.OpenRead(player_settingfile))
            {
                XmlSerializer ser = new XmlSerializer(typeof(Knight));
                return (Knight)ser.Deserialize(stream);
            }
        }
        private static Mage LoadMage()
        {
            using (Stream stream = File.OpenRead(player_settingfile))
            {
                XmlSerializer ser = new XmlSerializer(typeof(Mage));
                return (Mage)ser.Deserialize(stream);
            }
        }
        Mage new_Mage = new Mage();
        NPC new_npc = new NPC();
        Knight new_knight = new Knight();
        private void button4_Click(object sender, EventArgs e)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(@"C:\Users\GHOST\source\repos\RPG_GAME_PROJECT\RPG_GAME_PROJECT\bin\Debug\RPG_GAME_PROJECT\characterSettings\player.xml");
            XmlNodeList nodes = doc.SelectNodes("//c_c");
            string char_name = nodes[0].InnerText;
            Image knight_attack = Image.FromFile("C:\\Users\\GHOST\\source\\repos\\RPG_GAME_PROJECT\\lf2  gifs\\liso_ball.gif");
            Image mage_mana_attack= Image.FromFile("C:\\Users\\GHOST\\source\\repos\\RPG_GAME_PROJECT\\lf2  gifs\\ice_ball.gif");
            Image mage_attack = Image.FromFile("C:\\Users\\GHOST\\source\\repos\\RPG_GAME_PROJECT\\lf2  gifs\\magic_ball.gif");
            Image Knight_mana_attack = Image.FromFile("C:\\Users\\GHOST\\source\\repos\\RPG_GAME_PROJECT\\lf2  gifs\\liso_ball_magic.gif");
            Image enemey_attack = Image.FromFile("C:\\Users\\GHOST\\source\\repos\\RPG_GAME_PROJECT\\lf2  gifs\\julian_ball.gif");
            Image enemy_mana_attack = Image.FromFile("C:\\Users\\GHOST\\source\\repos\\RPG_GAME_PROJECT\\lf2  gifs\\fire_ball.gif");
            

            if (char_name == "Mage")
            {
                if(new_npc.isAlive()&&new_Mage.isAlive())
                {
                    if (((Button)sender).Text == "Attack")
                    {
                        hero_attack.Left = 151;
                        hero_attack.Image = mage_attack;
                        pictureBox2.Image = enemey_attack;
                        timer1.Start();
                        pictureBox2.Left = 382;
                        timer2.Start();
                        new_npc.TakeDamage();
                        new_Mage.TakeDamage_p();
                        npc_h.Text = "Health: " + new_npc.Health;
                        npc_mana.Text = "Mana: " + new_npc.Mana;
                        player_h.Text = "Health: " + new_Mage.Health;
                        player_mana.Text = "Mana:" + new_Mage.Mana;
                    }
                    if (((Button)sender).Text == "Mana_Attack")
                    {
                        hero_attack.Left = 151;
                        hero_attack.Image = mage_mana_attack;
                        timer1.Start();
                        pictureBox2.Image = enemy_mana_attack;
                        pictureBox2.Left = 382;
                        timer2.Start();
                        new_npc.TakeDamage_mana();
                        new_Mage.use_mana_p();
                        new_npc.use_mana_p();
                        new_Mage.TakeDamage_mana_p();
                        new_npc.exilir();
                        npc_h.Text = "Health: " + new_npc.Health;
                        npc_mana.Text = "Mana: " + new_npc.Mana;
                        player_h.Text = "Health: " + new_Mage.Health;
                        player_mana.Text = "Mana:" + new_Mage.Mana;
                    }
                    if (((Button)sender).Text == "Special")
                    {
                        new_Mage.healing();
                        new_Mage.use_mana_p();
                        new_npc.exilir();
                        player_h.Text = "Health: " + new_Mage.Health;
                        player_mana.Text = "Mana:" + new_Mage.Mana;
                        npc_h.Text = "Health: " + new_npc.Health;
                        npc_mana.Text = "Mana: " + new_npc.Mana;
                    }
                }
                if (new_npc.IsDead() && new_Mage.IsDead()) MessageBox.Show("   Tie  ");
                else if (new_npc.IsDead()) MessageBox.Show(" You Win ");
                else if (new_Mage.IsDead()) new_Mage.allto_0();
            }
            else
            {
                if (new_npc.isAlive() && new_knight.isAlive())
                {
                    if (((Button)sender).Text == "Attack")
                    {
                        hero_attack.Left = 151;
                        hero_attack.Image = knight_attack;
                        pictureBox2.Image = enemey_attack;
                        timer1.Start();
                        new_npc.TakeDamage();
                        npc_h.Text = "Health: " + new_npc.Health;
                        npc_mana.Text = "Mana: " + new_npc.Mana;
                        pictureBox2.Left = 382;
                        timer2.Start();
                        new_knight.TakeDamage_p();
                        player_h.Text = "Health: " + new_knight.Health;
                        player_mana.Text = "Mana:" + new_knight.Mana;
                        
                    }
                    if (((Button)sender).Text == "Mana_Attack")
                    {
                        hero_attack.Left = 151;
                        hero_attack.Image = Knight_mana_attack;
                        timer1.Start();
                        pictureBox2.Image = enemy_mana_attack;
                        pictureBox2.Left = 382;
                        timer2.Start();
                        new_npc.TakeDamage_mana();
                        new_knight.use_mana_p();
                        new_npc.use_mana_p();
                        new_knight.TakeDamage_mana_p();
                        new_npc.exilir();
                        npc_h.Text = "Health: " + new_npc.Health;
                        npc_mana.Text = "Mana: " + new_npc.Mana;
                        player_h.Text = "Health: " + new_knight.Health;
                        player_mana.Text = "Mana:" + new_knight.Mana;

                    }
                    if (((Button)sender).Text == "Special")
                    {
                        new_knight.mana_fill();
                        new_npc.exilir();
                        player_h.Text = "Health: " + new_knight.Health;
                        player_mana.Text = "Mana:" + new_knight.Mana;
                        npc_h.Text = "Health: " + new_npc.Health;
                        npc_mana.Text = "Mana: " + new_npc.Mana;
                    }
                }
                if (new_npc.IsDead() && new_knight.IsDead()) MessageBox.Show("   Tie  ");
                else if (new_npc.IsDead()) MessageBox.Show("You Win ");
                else if (new_knight.IsDead()) new_knight.allto_0();
            }
        }
     private void button5_Click(object sender, EventArgs e)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(@"C:\Users\GHOST\source\repos\RPG_GAME_PROJECT\RPG_GAME_PROJECT\bin\Debug\RPG_GAME_PROJECT\characterSettings\player.xml");
            XmlNodeList nodes = doc.SelectNodes("//c_c");
            string char_name = nodes[0].InnerText;
            if (char_name == "Mage")
            {
                player_pic.Image = Image.FromFile("C:\\Users\\GHOST\\source\\repos\\RPG_GAME_PROJECT\\lf2  gifs\\sorcerer_breathing.gif");
                new_Mage = LoadMage();
            }
            else
            {
                player_pic.Image = Image.FromFile("C:\\Users\\GHOST\\source\\repos\\RPG_GAME_PROJECT\\lf2  gifs\\louis_breathing.gif");
                new_knight = LoadKnight();
            }
            XmlNode healthNode1 = doc.SelectSingleNode("//Health");
            XmlNode manaNode1 = doc.SelectSingleNode("//Mana");
            if (healthNode1 != null && manaNode1 != null)
            {
                string healthValue1 = healthNode1.InnerText;
                string manaValue1 = manaNode1.InnerText;
                player_h.Text = "Health: " + healthValue1;
                player_mana.Text = "Mana: " + manaValue1;
            }
            ///////////////////////////////////////////////enmey  load 
            XmlDocument doc1 = new XmlDocument();
            doc1.Load(@"C:\Users\GHOST\source\repos\RPG_GAME_PROJECT\RPG_GAME_PROJECT\bin\Debug\RPG_GAME_PROJECT\characterSettings\npc.xml");
            XmlNodeList nodes1 = doc1.SelectNodes("//Name");
            string char_name1 = nodes1[0].InnerText;
            if (char_name1 == "Demon")
            {
                enemy_pic.Image = Image.FromFile("C:\\Users\\GHOST\\source\\repos\\RPG_GAME_PROJECT\\lf2  gifs\\julian_breathing.gif");
            }
            else
            {
                enemy_pic.Image = Image.FromFile("C:\\Users\\GHOST\\source\\repos\\RPG_GAME_PROJECT\\lf2  gifs\\firzen_breathing.gif");
            }
            XmlNode healthNode = doc1.SelectSingleNode("//Health");
            XmlNode manaNode = doc1.SelectSingleNode("//Mana");
            if (healthNode != null && manaNode != null)
            {
                string healthValue = healthNode.InnerText;
                string manaValue = manaNode.InnerText;
                npc_h.Text = "Health: " + healthValue;
                npc_mana.Text = "Mana: " + manaValue;
            }
            new_npc = LoadNPC();
        }

        
        private void timer1_Tick(object sender, EventArgs e)
        {
            hero_attack.Visible = true;
            hero_attack.Left += 25;

            if (hero_attack.Left >= 395)
            {
                timer1.Stop();
                hero_attack.Visible = false;  // Hide the PictureBox
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            pictureBox2.Visible = true;
            pictureBox2.Left -= 25;  // Move the pictureBox2 towards the right
            if (pictureBox2.Left <= 155)  // Adjust the condition as per your requirements
            {
                timer2.Stop();
                pictureBox2.Visible = false;  // Hide the PictureBox
            }
        }

    }
}
