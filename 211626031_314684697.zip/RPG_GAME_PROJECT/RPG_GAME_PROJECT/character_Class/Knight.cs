﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RPG_GAME_PROJECT.character_Class
{
    public class Knight:player
    {
        string name_class1;
        public void mana_fill()
        {
            int plus_mp = 15;
            Mana += plus_mp;
            Health -= 5;
        }
        public override void allto_0()
        {
            MessageBox.Show("NOOOO KINGHT LOST BECAUSE OF YOU ");
        }
        public string c_c
        {
            get
            {
                return name_class1;
            }
            set
            {
                name_class1 = "Knight";
            }
        }
       
        public Knight()
            : base()
        {
        }
        public Knight(string name, Offense_Defense of, int strength_, int hp, int mp, string name_class)
        {
            Name = name;
            Strength = strength_;
            Health = hp;
            Mana = mp;
            name_class1 = name_class;
            Of_Def = Offense_Defense.Unknown;
            if ((int)Of_Def == 15)
            {
                Mana += (int)Of_Def;
            }
            else
            {
                Health += (int)Of_Def;
            }
            Mana = mp;
        }
    }

}

