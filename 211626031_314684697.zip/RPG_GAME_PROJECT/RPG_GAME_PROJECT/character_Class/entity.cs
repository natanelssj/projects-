﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using System.Windows.Forms;

namespace RPG_GAME_PROJECT.character_Class
{

    public abstract class entity
    {
        #region Fieleds Region
         string _name;
         int _strength, _health, _mana;
        #endregion
        #region Properties Region
        public string Name
        {
            get { return _name; }
            set { _name = value;}
        }
        public int Strength
        {
            get { return _strength ; }
            set { _strength = value; }
        }
        public int Mana
        {
            get { return _mana ; }
            set { _mana = value; }
        }
        public int Health
        {
            get { return _health ; }
            set { _health = value; }
        }
        public virtual bool isAlive()
        {
            return Health > 0;
        }
        public virtual bool IsDead()
        {
            return Health <= 0;
        }
        public virtual void allto_0()
        {
            MessageBox.Show("NOOOO player lost ");
        }
        #endregion
        #region Constractor Region
        public entity()
        {
            Name = "";
            Strength = 0;
            Health = 0;
            Mana = 0;
        }
        #endregion
        #region Methods Region
        #endregion

    }
}
