﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace RPG_GAME_PROJECT.character_Class
{
    public enum Offense_Defense { Defense=15, Offense=10, Unknown }

    public class player : entity 
    {
        
         Offense_Defense _Add_static;
        public Offense_Defense Of_Def
        {
            get { return _Add_static; }
             set { _Add_static = value; }
        }
        public player()
            :base()
        {
        }
        public player(string name, Offense_Defense of_def,int strength_,int hp, int mana )
        {
            Name = name;
            Of_Def = of_def;
            Strength = strength_;
            Health = hp;
            Of_Def = Offense_Defense.Unknown;
            if ((int)Of_Def== 15)
            {
                Mana += (int)Of_Def;
            }
            else
            {
                Health += (int)Of_Def;
            }
            Mana = mana;
        }       
        public void TakeDamage_mana_p()
        {
            int damage = 25;
            this.Health -= damage;
        }
        public void TakeDamage_p()
        {
            int damege = 15;
            this.Health -= damege;
        }
        public void use_mana_p()
        {
            int use = 15;
            this.Mana -= use;
        }
    }
}
