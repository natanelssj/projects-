﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG_GAME_PROJECT.character_Class
{
    public class Mage : player
    {
        string name_class1;
        public void healing()
        {
            int heal = 15;
            Health += heal;
        }
        
        public string c_c
        {
            get
            {
                return name_class1;
            }
            set
            {
                name_class1 = "mage";
            }
        }
        public Mage()
            : base()
        {
        }
        public Mage(string name,Offense_Defense of, int strength_, int hp, int mp, string name_class)
        {
            Name = name;
            Strength = strength_;
            Health = hp;
            Mana = mp;
            name_class1 = name_class;
            Of_Def = Offense_Defense.Unknown;
            if ((int)Of_Def == 15)
            {
                Mana += (int)Of_Def;
            }
            else
            {
                Health += (int)Of_Def;
            }
            Mana = mp;
        }
    }
}

