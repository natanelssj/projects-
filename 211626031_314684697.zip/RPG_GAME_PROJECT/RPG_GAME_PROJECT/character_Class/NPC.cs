﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
namespace RPG_GAME_PROJECT.character_Class
{ 
    public class NPC : entity
    {
        public NPC()
            : base()
        { 
        }
        public NPC(string name, int strength_, int hp,int mp)
        {
            Name = name;
            Strength = strength_;
            Health = hp;
            Mana = mp;
        }
        public void TakeDamage_mana()
        {
            int damage =30;
            this.Health -= damage;
        }
        public void TakeDamage()
        {
            int damege = 20;
            this.Health -= damege;
        }
        public void use_mana_p()
        {
            int use = 15;
            this.Mana -= use;
        }
        public void exilir()
        {
            int hp=10, mp=10;
            Health += hp;
            Mana += mp;
        }
    }
}
