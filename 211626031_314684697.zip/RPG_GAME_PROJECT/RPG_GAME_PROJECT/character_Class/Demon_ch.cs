﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG_GAME_PROJECT.character_Class
{
   public class Demon_ch :NPC
    {
        protected int reduce_life;
        public int  Reduce
        {
            get { return reduce_life; }
             set
            {
                if (value > 5)
                {
                    reduce_life = 5;
                }
                else
                {
                    reduce_life = value;
                }
            }
        }
        public Demon_ch()
            : base()
        {
        }
        public Demon_ch(string name, int strength_, int hp, int mp,int reducer_life)
        {
            Name = name;
            Strength = strength_;
            Health = hp;
            Mana = mp;
            Reduce = reducer_life;
        }
    }


