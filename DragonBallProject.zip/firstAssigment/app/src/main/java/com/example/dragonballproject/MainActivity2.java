package com.example.dragonballproject;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        // Get data passed from MainActivity
        String name = getIntent().getStringExtra("NAME");
        String description = getIntent().getStringExtra("Description");  // Fix key
        int image = getIntent().getIntExtra("Image", 0);  // Fix key

        TextView nameTextView = findViewById(R.id.NameCharacter);
        TextView descriptionTextView = findViewById(R.id.DescriptionCharacter);
        ImageView imageCharacter = findViewById(R.id.ImageCharacter);

        nameTextView.setText(name);
        descriptionTextView.setText(description);
        imageCharacter.setImageResource(image);  // Set image properly
    }
}
