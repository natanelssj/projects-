package com.example.dragonballproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class DB_RecycleViewAdapter extends RecyclerView.Adapter<DB_RecycleViewAdapter.MyViewHolder> {
    private final RecyclerViewInterface recyclerViewInterface;
    private final Context context;
    private final ArrayList<characters> characters;

    // Corrected constructor to include context parameter
    public DB_RecycleViewAdapter(Context context, RecyclerViewInterface recyclerViewInterface, ArrayList<characters> characters) {
        this.context = context;
        this.recyclerViewInterface = recyclerViewInterface;
        this.characters = characters;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Get LayoutInflater from context
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.item_layout, parent, false);
        return new MyViewHolder(view, recyclerViewInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        characters character = characters.get(position);
        holder.tvName.setText(character.getCharacterName());
        holder.tv1Letter.setText(character.getCharacterDescription());
        holder.imageView.setImageResource(character.getImage());
    }

    @Override
    public int getItemCount() {
        return characters.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView tvName, tv1Letter;

        public MyViewHolder(@NonNull View itemView, RecyclerViewInterface recyclerViewInterface) {
            super(itemView);
            imageView = itemView.findViewById(R.id.charater_img);
            tvName = itemView.findViewById(R.id.CharacterName);
            tv1Letter = itemView.findViewById(R.id.Description);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (recyclerViewInterface != null) {
                        int pos = getAdapterPosition();
                        if (pos != RecyclerView.NO_POSITION) {
                            recyclerViewInterface.onItemClicked(pos);
                        }
                    }
                }
            });
        }
    }
}
