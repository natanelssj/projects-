package com.example.dragonballproject;

public class characters {
    public characters(int  image, String characterDescription, String characterName) {
        this.image = image;
        this.characterDescription = characterDescription;
        this.characterName = characterName;
    }

    String characterName;
    String characterDescription;
    int image;

    public int getImage() {
        return image;
    }

    public String getCharacterDescription() {
        return characterDescription;
    }

    public String getCharacterName() {
        return characterName;
    }
}