package com.example.dragonballproject;

public interface RecyclerViewInterface {
    void onItemClicked(int position);
}
