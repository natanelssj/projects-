package com.example.dragonballproject;

import android.content.Intent;
import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements RecyclerViewInterface {
    ArrayList<characters> characters = new ArrayList<>();

    int[] characterImg = {
            R.drawable.goku, R.drawable.vegeta, R.drawable.jiren,
            R.drawable.piccolo, R.drawable.friza, R.drawable.gohan,
            R.drawable.trunks, R.drawable.cell, R.drawable.majin_buu
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.Recycler);
        setCharactersModels();
        DB_RecycleViewAdapter adapter = new DB_RecycleViewAdapter(this, this,characters);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setCharactersModels() {
        String[] charactersNames = getResources().getStringArray(R.array.all_characters_txt);
        String[] charactersDescription = getResources().getStringArray(R.array.all_characters_description);

        int minLength = Math.min(charactersNames.length, Math.min(charactersDescription.length, characterImg.length));
        for (int i = 0; i < minLength; i++) {
                    characters.add(new characters(
                    characterImg[i],
                    charactersDescription[i],
                    charactersNames[i]
            ));
        }
    }

    @Override
    public void onItemClicked(int position) {
        Intent intent =new Intent(MainActivity.this, MainActivity2.class);
        intent.putExtra("NAME", characters.get(position).getCharacterName());
        intent.putExtra("Description", characters.get(position).getCharacterDescription());
        intent.putExtra("Image", characters.get(position).getImage());


        startActivity(intent);
    }

}
