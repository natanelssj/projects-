// Course: Advanced C programming
// exercise 2, question 2
// file name: ex2_q2.c

// --------------------------- //
//
//	Assigned by:
//		Student1_Full_Name #ID
//		Student2_Full_Name #ID
//
// --------------------------- //

// --------------------------------------- //
// Include and definition package section:
// --------------------------------------- //
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#define scanf_s scanf
#define ROWS 4
#define COLS 5
// --------------------------------------- //
// Types declration section:
// --------------------------------------- //
typedef struct four
{
	int i, j, d, value;
} four;

typedef struct list
{
	four data;
	struct list* next;
} list;
// --------------------------------------- //
// Functions declration section:
// --------------------------------------- //
unsigned long student_id();
int createArrayAndList(int A[][COLS], list** lst, four** arr, int rows, int cols);
four createFour(int i, int j, int d, int value);
list* createElement(four data);
void printArray(four* arr, int n);
void printList(list* lst);
void freeDynamic(list** lst, four** arr);

// --------------------------------------- //
// Main section:
// --------------------------------------- //
int main()
{
	unsigned long id_num;
	int n;
	list* lst = NULL;
	four* arr = NULL;
	int A[ROWS][COLS] = {
		{0, 6, 5, 6, 6},
		{8, 9, 5, 6, 7},
		{7, 6, 5, 4, 7},
		{9, 8, 1, 6, 7},
	};

	// Start Program:
	printf("Start Program\n");

	// call functions:
	n = createArrayAndList(A, &lst, &arr, ROWS, COLS);

	// write output:
	printf("Output:\n");
	printArray(arr, n);
	printList(lst);

	// free dynamic:
	freeDynamic(&lst, &arr);

	return 0;
}
// --------------------------- //

/// <summary>
/// This function allocate a dynamic array and list, 
/// from elements found at matrix A 
/// </summary>
/// <param>int A[][] - The static matrix</param>
/// <param>list** lst - Pointer to the pointer of the head of the list</param>
/// <param>four** arr - Pointer to the pointer of the head of the array</param>
/// <param>int rows - The number of rows in the matrix</param>
/// <param>int cols - The number of colums in the matrix</param>
/// <returns>Number of requested elements in found in A</returns>
int createArrayAndList(int A[][COLS], list** lst, four** arr, int rows, int cols)
{
	int counter = 0, i = 0, j = 0;
	int d, val;
	list* temp = NULL;
	for (i = 0; i < rows; i++)
	{
		for (j = 0; j < cols; j++)
		{
			d = j - i;
			if (A[i][j] - j == d)
			{
				if (*arr == NULL)
				{
					*arr = (four*)malloc(sizeof(four));
					(*arr)[0] = createFour(i, j, d, A[i][j]);
					*lst = createElement((*arr)[0]);
					temp = *lst;
				}
				else
				{
					*arr = (four*)realloc(*arr, (counter + 1) * sizeof(four));
					(*arr)[counter] = createFour(i, j, d, A[i][j]);
					temp->next = createElement((*arr)[counter]);
					temp = temp->next;
				}

				counter++;
			}

		}
	}
	return counter;
}

// --------------------------- //

/// <summary>
/// The function receives 4 integer values 
/// and returns a value from type four.
/// </summary>
/// <param>int i - The cell row number in matrix</param>
/// <param>int j - The cell colum number in the matrix</param>
/// <param>int d - The difference between the consecutive values</param>
/// <param>int value - The value at position [i,j] in matrix</param>
/// <returns>value from type four</returns>
four createFour(int i, int j, int d, int value)
{
	// your code:
	four four_array;
	four_array.i = i;
	four_array.d = d;
	four_array.j = j;
	four_array.value = value;
	return four_array;
}
// --------------------------- //

/// <summary>
/// The function receives a value from type four
/// and returns a dynamic element from type list  
/// </summary>
/// <param>four data - value from type four</param>
/// <returns>dynamic value from type list</returns>
list* createElement(four data)
{
	// your code:
	list* ptr = malloc(sizeof(list));
	ptr->data = data;
	ptr->next = NULL;
	return ptr;
}
// --------------------------- //


/// <summary>
/// The function receives an array from type four,
/// and print its values.  
/// </summary>
/// <param>four* arr - the array</param>
/// <param>int n - number of elements</param>
/// <returns>None</returns>
void printArray(four* arr, int n)
{
	// your code:
	printf("array:\n");
	for (int i = 0; i < n; i++)
	{
		printf("  %d  ", arr[i].value);
		printf("  %d  ", arr[i].i);
		printf("  %d  ", arr[i].j);
		printf("  %d\n", arr[i].d);
	}
}
// --------------------------- //


/// <summary>
/// The function receives a list,
/// and print its values.  
/// </summary>
/// <param>list* lst - the list</param>
/// <returns>None</returns>
	// your code:
void printList(list* lst)
{
	// your code:
	int count = 0;
	printf("list:\n");
	while (lst != NULL)
	{
		printf("\n %d ", lst->data.value);
		printf("  %d  ", lst->data.i);
		printf("  %d  ", lst->data.j);
		printf("  %d\n", lst->data.d);
		lst = lst->next;
	}
}

// --------------------------- //

/// <summary>
/// The function free all allocated memory of the program. 
/// </summary>
/// <param>list** lst - Pointer to the pointer of the head of the list</param>
/// <param>four** arr - Pointer to the pointer of the head of the array</param>
/// <returns>None</returns>
void freeDynamic(list** lst, four** arr)
{
	if (*lst == NULL && *arr == NULL)
		return; // Nothing to free, both list and array are empty

	// Free the linked list
	list* current = *lst;
	list* next;
	while (current != NULL)
	{
		next = current->next;
		free(current);
		current = next;
	}
	*lst = NULL; // Set the list pointer to NULL after freeing

	// Free the array
	free(*arr);
	*arr = NULL; // Set the array pointer to NULL after freeing
}

// --------------------------- //
