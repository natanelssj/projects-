﻿// Course: Advanced C programming
// exercise 1, question 2
// file name: ex1_q2.c
#define _CRT_SECURE_NO_WARNINGS
// --------------------------- //
// include package section:
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// --------------------------- //
//
//	Assigned by:
//		נתנאל ראחמינוב  #314684697#
//		דניאל פינחסוב #206994188#//
// --------------------------- //

// structs and function declarations section:
typedef struct point
{
	int x, y;
}point;

typedef struct polygon
{
	int n;
	point* points;
	double scope;
}polygon;

void scanPoint(point* p);
double distance(point* p1, point* p2);
double calculateScope(point* points, int n);
polygon* createPolygon();
int addPoint(polygon* poly);
int removePoint(polygon* poly, int idx);
void freeMemory(polygon* poly);

// --------------------------- //

int main()
{
	int i, n, idx;
	polygon* poly;

	// Start Program:
	printf("Start Program\n");

	// call functions:
	poly = createPolygon();
	printf("How many points to add: ");
	scanf_s("%d", &n);

	for (i = 0; i < n; i++)
	{
		printf("Point #%d: \n", i + 1);
		addPoint(poly);
	}

	printf("Enter index value to remove, invalid index to stop: ");
	do
	{
		scanf_s("%d", &idx);
	} while (removePoint(poly, idx));

	// write output:
	printf("Output: Scope of polygon: %.2lf\n", poly->scope);
	freeMemory(poly);

	return 0;
}
// --------------------------- //


/// <summary>
/// Function scan a point in the plane,
/// Used as auxiliary function for createPolygon.
/// </summary>
/// <param>point* p - pointer to p</param>
/// <returns>None</returns>
void scanPoint(point* p)
{
	// your code:
	printf("enter x:");
	scanf_s("%d", &p->x);
	printf("enter y:");
	scanf_s("%d", &p->y);
}
// --------------------------- //


/// <summary>
/// Function allocate an empty polygon.
/// </summary>
/// <returns>New allocated polygon</returns>
polygon* createPolygon()
{
	// your code:
	polygon* ptr = malloc(sizeof(polygon));
	if (ptr == NULL)
	{
		printf("failed creating polygon");
		return NULL;
	}
	ptr->n = 0;
	ptr->points = NULL;
	ptr->scope = 0;
	
	return ptr;
}
// --------------------------- //


/// <summary>
/// Function calculates distance between 2 adjacent points  
/// </summary>
/// <param>point* p1 - pointer to the first point</param>
/// <param>point* p2 - pointer to the second point</param>
/// <returns>The Euclidean distance between p1 and p2</returns>
double distance(point* p1, point* p2)
{
	// your code:
	double dx = (double)(p1->x - p2->x);
	double dy = (double)(p1->y - p2->y);
	return sqrt((dx*dx) + (dy*dy));


}
// --------------------------- //


/// <summary>
/// Function calculates and returns the Scope of a polygon.
/// </summary>
/// <param>point* points - array of points</param>
/// <param>int n - size of the array</param>
/// <returns>The Scope of a polygon</returns>
double calculateScope(point* points, int n)
{
	// your code:
	double result = 0;
	if (n < 3)
	{
		return 0;
	}
	else {
		for (int i = 0; i < n - 1; i++)
			{
				result += distance(&points[i], &points[i + 1]);
			}
		result += distance(&points[0], &points[n - 1]);
			return result;
	}
	

}
// --------------------------- //


/// <summary>
/// Function add a new point at the end of the polygon,
/// and update the scope falue.
/// </summary>
/// <param>polygon* poly - pointer to polygon</param>
/// <returns>1- success, 0- failure</returns>
int addPoint(polygon* poly)
{
	// your code:
	poly->points = (point*)realloc(poly->points, (poly->n + 1) * sizeof(point));
	if (poly->points == NULL)
	{
		return 0;
	}
	else
	{
		scanPoint(&(poly->points[poly->n]));
		poly->n +=1;
		poly->scope += calculateScope(poly->points, poly->n);
		return 1;
	}
}
	


// --------------------------- //


/// <summary>
/// Function remove a point from the polygon,
/// at spesific index.
/// </summary>
/// <param>polygon* poly - pointer to polygon</param>
/// <param>int idx - the index to remove</param>
/// <returns>1- success, 0- failure</returns>
int removePoint(polygon* poly, int idx)
{
	// your code:
	int i, j;
	point* temp = malloc(poly->n * sizeof(point));
	if (idx < 0 || idx > poly->n) 
	{
		printf("index out of range \n");
		return 0;
	}
	if (temp && poly->points)
	{
		for (i = 0; i < poly->n; i++)
		{
			temp[i].x = poly->points[i].x;
			temp[i].y = poly->points[i].y;
		}
		if (poly->n - 1 == idx)
		{
			temp = (point*)realloc(temp, (poly->n - 1) * sizeof(point));
			poly->n--;
			free(poly->points);
			poly->points = NULL;
			poly->points = temp;
			poly->scope = calculateScope(poly->points, poly->n);
			return 1;
		}
		for (j = idx; j < poly->n - 1; j++)
		{
			temp[j].x = poly->points[j + 1].x;
			temp[j].y = poly->points[j + 1].y;
		}
		temp = (point*)realloc(temp, (poly->n - 1) * sizeof(point));

		if (temp)
		{
			poly->n--;
			free(poly->points);
			poly->points = NULL;
			poly->points = temp;
			poly->scope = calculateScope(poly->points, poly->n);
			return 1;
		}
		printf("failed\n");
		return 0;
	}

}

 //--------------------------- //


/// <summary>
/// Function free alocated memory. 
/// </summary>
/// <param>polygon* poly - pointer to polygon</param>
/// <returns>None</returns>
void freeMemory(polygon* poly)
{
	// your code:
	free(poly->points);
	poly->points = NULL;
	free(poly);
	poly = NULL;
}
// --------------------------- //