#include "linkedList.h"
#include <stdio.h>
#include <stdlib.h>
/*PART A:
 --------*/
numberNode* createNode(unsigned int newValue)
{
	//Write your code here
	numberNode* ptr=malloc(sizeof(numberNode));
	ptr->data = newValue;
	ptr->next = NULL;
	return ptr;

}

void addToEnd(numberNode** list, unsigned int newValue)
{
	//Write your code here
	numberNode* ptr = (numberNode*)malloc(sizeof(numberNode));
	ptr->data = newValue;
	ptr->next = NULL;

	if (*list == NULL)
	{
		*list = ptr;
	}
	else
	{
		numberNode* going = *list;
		while (going->next != NULL)
		{
			going = going->next;
		}
		going->next = ptr;
	}
}

int removeHead(numberNode** list)
{
	//Write your code here
	numberNode* ptr = *list;
	(*list) = (*list)->next;
	return ptr->data;
}

void cleanList(numberNode** list)
{
	//Write your code here
	numberNode* current = *list;
	numberNode* next;

	while (current != NULL)
	{
		next = current->next;
		free(current);
		current = next;
	}
	*list = NULL;
}


/*PART B:
 --------*/
void printList(numberNode* list)
{
	//Write your code here
	while (list!=NULL)
	{
		printf("%d ", list->data);
		list=list->next;
	}
}

int listLength(numberNode* list)
{
	//Write your code here
	numberNode* ptr = list;
	int counter = 0;
	while (ptr!=NULL)
	{
		ptr = ptr->next;
		counter++;
	}
	return counter;
}

/*PART C:
 --------*/
void reverseList(numberNode** list)
{
	//Write your code here
	numberNode* prev=NULL, * next=NULL, * current;
	current = *list;
	while (current)
	{
		next = current->next;
		current->next = prev;
		prev = current;
		current = next;
	}
	*list = prev;
}