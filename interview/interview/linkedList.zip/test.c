#include "linkedList.h"
#include <stdio.h>

int main(void)
{

	printf("Testing results:\n");
	numberNode* list = 0;
	printf("Empty list: ");
	printList(list);
	printf("\n");

	addToEnd(&list, 5);
	addToEnd(&list, 9);
	addToEnd(&list, 1);
	addToEnd(&list, 6);

	printf("The original list: ");
	printList(list);
	printf("\n");
	printf("List length: %d\n", listLength(list));
	reverseList(&list);
	printf("The list after reversing: ");
	printList(list);
	printf("\n");

	for (int i = 0; i < 2; i++)
	{
		removeHead(&list);
	}
	printf("The list after two head removes: ");
	printList(list);
	printf("\n");

	cleanList(&list);

	return 0;
}