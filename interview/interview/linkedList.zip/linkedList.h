#pragma once
#ifndef LINKEDLIST_H
#define LINKEDLIST_H

/*PART A:
 ---------
a link that contains a positive integer value */
typedef struct numberNode
{
    //Write your code here
    int data;
    struct numberNode* next;
} numberNode;


numberNode* createNode(unsigned int newValue); // initialize list
void addToEnd(numberNode** list, unsigned int newValue); // add new link in the end of list with newValue in it
int removeHead(numberNode** list); // return the value from the first link in list, and change the first link to head->next. return -1 if list is empty
void cleanList(numberNode** list); // delete all links from memory


/*PART B:
 ---------*/
void printList(numberNode* list); // prints the list
int listLength(numberNode* list); // gets a list and returns its length.


/*PART C:
 ---------*/
void reverseList(numberNode** list); // reverses the list (updates the original pointer).

#endif // LINKEDKIST_H
